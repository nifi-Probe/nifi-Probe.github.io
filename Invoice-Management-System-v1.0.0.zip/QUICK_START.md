# 🚀 Quick Start - Invoice Management System

## Für die Ungeduldigsten (3 Schritte ⏱️)

### 1️⃣ **download** - App herunterladen
- Gehe zu GitHub Releases: https://github.com/USERNAME/invoice-management-system/releases
- Klick auf **Invoice_Management_System_v1.0.0.zip** (oder aktuelle Version)
- Datei an gewünschten Ort extrahieren (z.B. C:\Rechnungsapp)

### 2️⃣ **setup** - Erste Installation (nur einmal!)
- Öffne den App-Ordner
- **Doppelklick auf `setup.bat`**
- Fenster fragt nach Python - drücke `Enter`
- ⏳ Warten (ca. 30 Sekunden)
- ✅ "Setup erfolgreich abgeschlossen" → Fenster schließen

### 3️⃣ **start** - App starten
- **Doppelklick auf `setup.bat`** (ja, nochmal!)
- ODER: Windows-Terminal, zu Ordner navigieren, `python src/ui/main.py` eingeben
- 🎉 App startet!

---

## Erste Rechnung erstellen (5 Minuten ⏰)

1. **Kundenname:** Firma eingeben (z.B. "Musterfirma GmbH")
2. **USt-IdNr:** Steuernummer eingeben (z.B. "DE123456789")
3. **Kontonummer:** Deine Kontonummer (z.B. "DE89 3704 0044 0532 0130 00")
4. **Rechnungsbetrag:** Summe in Euro (z.B. "500.00")
5. **Dienstleistung:** kurze Beschreibung (z.B. "Webentwicklung März 2025")
6. **MwSt %:** normalerweise 19% (bereits voreingestellt)
7. **Klick "Rechnung erstellen"** 
8. ✅ PDF automatisch auf Desktop/App-Ordner gespeichert!

---

## 📂 Wo sind meine Rechnungen?

- **PDFs:** Desktop Ordner (oder App-Ordner als Fallback)
- **Daten:** `invoice.db` im App-Ordner (automatisch erstellt)
- **Backup:** `backup.bat` ausführen für Datensicherung

---

## ⚠️ Wichtig zu wissen

| Problem | Lösung |
|---------|--------|
| Python nicht gefunden | [Download](https://www.python.org/downloads/) + während Installation ✅ "Add to PATH" |
| PDF speichert nicht | Check Dateiberechtigungen, PDFs landen im App-Ordner |
| Fehler beim Start | Lösche `invoice.db`, starten Sie die App erneut |
| Kein Doppelklick auf .bat | Rechtsklick → "Als Administrator ausführen" |

---

## 📞 Mehr Info?

- **Ausführliche Anleitung:** Siehe [README.md](README.md)
- **Für Entwickler:** Siehe [GITHUB_SETUP_GUIDE.md](GITHUB_SETUP_GUIDE.md)
- **Was ist neu?** Siehe [CHANGELOG.md](CHANGELOG.md)
- **Fehler melden:** GitHub Issues

---

## 🎯 Nächste Schritte

- ✅ Setup.bat ausführen
- ✅ App testen
- ⭐ Mit Freunden teilen
- 💬 Feedback geben (GitHub Issues)

**Viel Erfolg! 💪**
