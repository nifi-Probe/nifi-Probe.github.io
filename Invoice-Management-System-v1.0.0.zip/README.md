# Invoice Management System - Rechnungsstellungs-App

Eine professionelle Python-Anwendung zur Verwaltung und Erstellung von Rechnungen mit automatischer PDF-Generierung.

## Features

✅ **Kundenverwaltung**
- Kunden hinzufügen und verwalten
- Kundendaten bearbeiten
- Kunden löschen (Rechnungen bleiben erhalten)
- Alle Rechnungen pro Kunde anzeigen

✅ **Rechnungsstellung**
- Professionelle PDF-Rechnungen
- Automatische Rechnungsnumerierung (YYYY-NNNN)
- Individuell einstellbare Mehrwertssteuer (%)
- Dienstleistungsbeschreibung
- Bankkonto/IBAN auf Rechnungen
- Automatisches aktuelles Datum

✅ **Automatisierung**
- Wiederkehrende monatliche Rechnungen
- Automatische PDF-Speicherung

✅ **Datenspeicherung**
- SQLite-Datenbank für Persistierung
- Rechnungsverlauf

## Installation

### Systemanforderungen
- Windows 7 oder höher
- Python 3.8+ (kostenlos von https://www.python.org/ erhältlich)

### Schritt-für-Schritt Installation

**Option 1: Automatisches Setup (Empfohlen)**

1. Lade die App herunter und entpacke sie
2. Doppelklick auf `setup.bat`
3. Folge den Anweisungen auf dem Bildschirm
4. Die App wird automatisch konfiguriert

**Option 2: Manuelles Setup**

1. Python 3.8+ installieren von https://www.python.org/
2. Terminal/PowerShell im App-Ordner öffnen
3. Folgende Befehle eingeben:
   ```
   python -m venv .venv
   .venv\Scripts\activate
   pip install -r requirements.txt
   ```

## Verwendung

### App starten
- **Über Desktop-Verknüpfung:** Doppelklick auf "RechnungsApp" 
- **Oder via Terminal:**
  ```
  .venv\Scripts\python.exe src/ui/main.py
  ```

### Workflow
1. **Kunde hinzufügen:** Gib Name, VAT-Nummer und Bankkonto ein
2. **Rechnung erstellen:** 
   - Wähle einen Kunden aus der Liste
   - Fülle Dienstleistung und Betrag aus
   - Stelle MwSt.-Satz ein
   - Klick "Rechnung erstellen"
3. **PDF wird automatisch gespeichert** im App-Ordner oder auf dem Desktop
4. **Rechnungen anzeigen:** Klick auf einen Kunden → alle seine Rechnungen werden angezeigt

## Datenspeicherung

- **Datenbank:** `invoice.db` (im App-Ordner)
- **PDFs:** Werden im `src/ui/` Ordner oder auf dem Desktop gespeichert
- **Kundendaten:** Verschlüsselung ist nicht aktiviert (sicher für kleine Unternehmen)

## Fehlerbehebung

**"Python ist nicht installiert"**
→ Python von https://www.python.org/ installieren und dabei **"Add Python to PATH"** aktivieren

**"Module nicht gefunden"**
→ Stelle sicher, dass die Virtual Environment aktiviert ist:
```
.venv\Scripts\activate
pip install -r requirements.txt
```

**"PDF kann nicht gespeichert werden"**
→ Verschoben automatisch in den App-Ordner. Prüfe Schreibberechtigungen.

**"App öffnet sich nicht"**
→ Terminal öffnen und testen:
```
.venv\Scripts\python.exe src/ui/main.py
```
Fehlerausgaben werden im Terminal angezeigt.

## Auf andere Geräte übertragen

1. **Kompletten App-Ordner kopieren** (außer `.venv` und `invoice.db`)
2. Auf dem neuen PC: `setup.bat` ausführen
3. Virtual Environment wird automatisch erstellt
4. Dependencies werden installiert

### Gemeinsame Datenbank synchronisieren

Falls mehrere Geräte die gleiche Datenbank verwenden sollen:
- `invoice.db` in Cloud-Speicher (OneDrive, Google Drive) speichern
- Pfad in `src/infrastructure/repository.py` anpassen
- Alternative: Regelmäßig Backups durchführen

## Fehler melden und Verbesserungen

Wenn Fehler auftreten:
1. **Terminal öffnen:** Im App-Ordner `cmd` öffnen
2. **App starten mit Fehlersichtbarkeit:**
   ```
   .venv\Scripts\python.exe src/ui/main.py
   ```
3. **Fehlerausgabe kopieren** und dokumentieren
4. **Dateistruktur überprüfen:** Alle Dateien sollten vorhanden sein
   ```
   src/
   ├── domain/
   ├── application/
   ├── infrastructure/
   └── ui/
   ```

## Sicherheit & Datenschutz

- Datenbank ist lokal auf dem PC
- Keine Internetverbindung nötig
- Rechnungen sind private PDF-Dateien
- Keine automatischen Updates (sparsam mit Ressourcen)

## Lizenz & Support

Diese App wurde für deine persönliche/geschäftliche Nutzung entwickelt.

**Kontakt für Updates/Fehlerberichte:** Siehe Dokumentation im Projektordner

---

**Version:** 1.0
**Datum:** Februar 2026
**Status:** Produktiv
